#!/usr/bin/env python3
"""
Tabelog Hyakumeiten Restaurant Scraper
=======================================
Enriches hyakumeiten-restaurants.json with detailed Tabelog data.

Usage:
    python scrape_tabelog.py                    # scrape all, 3s delay
    python scrape_tabelog.py --delay 2           # 2s delay between requests
    python scrape_tabelog.py --batch 500         # first 500 restaurants
    python scrape_tabelog.py --resume            # resume from checkpoint
    python scrape_tabelog.py --test              # scrape 5 restaurants for testing
"""

import argparse
import json
import logging
import re
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any

import requests
from bs4 import BeautifulSoup

# ─── Configuration ───────────────────────────────────────────────────────────

BASE_DIR = Path(r"C:\Users\hello\kwonledge-base\tabelog")
INPUT_FILE = BASE_DIR / "hyakumeiten-restaurants.json"
OUTPUT_FILE = BASE_DIR / "hyakumeiten-restaurants-enriched.json"
CHECKPOINT_FILE = BASE_DIR / ".scrape_checkpoint.json"
ERROR_LOG = BASE_DIR / "scrape_errors.log"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Accept-Language": "ja-JP,ja;q=0.9,en-US;q=0.8,en;q=0.7",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Connection": "keep-alive",
}

TIMEOUT = 15
MAX_RETRIES = 3
RETRY_DELAY = 5

# ─── Logging ─────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(BASE_DIR / "scrape.log", encoding="utf-8"),
    ],
)
log = logging.getLogger("tabelog-scraper")

error_log_fh = open(ERROR_LOG, "a", encoding="utf-8")


def log_error(msg: str):
    error_log_fh.write(f"{datetime.now().isoformat()} | {msg}\n")
    error_log_fh.flush()


# ─── Extraction Helpers ─────────────────────────────────────────────────────

def extract_review_saved_counts(soup: BeautifulSoup) -> tuple[int | None, int | None]:
    """Extract review count and saved count from header."""
    review_count = None
    saved_count = None

    # Review: look for "口コミ659人" in header
    for el in soup.select(".rdheader-rating__review, .rdheader-rating__review-target"):
        text = el.get_text(strip=True)
        m = re.search(r"(\d[\d,]*)人", text)
        if m:
            review_count = int(m.group(1).replace(",", ""))
            break

    # Saved: look for "保存24672人" in header
    for el in soup.select(".rdheader-rating__hozon, .rdheader-rating__hozon-target"):
        text = el.get_text(strip=True)
        m = re.search(r"(\d[\d,]*)人", text)
        if m:
            saved_count = int(m.group(1).replace(",", ""))
            break

    return review_count, saved_count


def extract_score_boxes(soup: BeautifulSoup) -> list[dict]:
    """Extract rating distribution (taste, atmosphere, service, etc.).

    Format: "3.66659人" means score=3.66, count=659
    """
    scores = []
    for box in soup.select("div.score-box"):
        text = box.get_text(strip=True)
        # Score is always X.XX (2 decimal places), rest is count
        m = re.search(r"(\d\.\d{2})(\d+)人", text)
        if m:
            scores.append({"score": float(m.group(1)), "count": int(m.group(2))})
    return scores


def extract_awards(soup: BeautifulSoup) -> list[str]:
    """Extract clean award names from badge elements."""
    awards = set()
    # The cleanest source: badge-link elements
    for el in soup.select(".rstinfo-table-badge-award__badge-link, .rdheader-badge-award__target"):
        text = el.get_text(strip=True)
        # Format: "食堂 百名店 2026 選出店"
        m = re.search(r"([a-zA-Z\u3040-\u9FFF\s]+?)\s*百名店\s*(\d{4})\s*選出店", text)
        if m:
            genre = m.group(1).strip()
            year = m.group(2)
            awards.add(f"{genre}百名店{year}選出店")

    # Fallback: also check tooltip elements for awards not in badge-link
    if not awards:
        for el in soup.select(".c-badge-hyakumeiten"):
            text = el.get_text(strip=True)
            m = re.search(r"([a-zA-Z\u3040-\u9FFF\s]+?)\s*百名店\s*(\d{4})\s*選出店", text)
            if m:
                genre = m.group(1).strip()
                year = m.group(2)
                awards.add(f"{genre}百名店{year}選出店")

    return sorted(awards)


def extract_budget_info(soup: BeautifulSoup) -> dict:
    """Extract budget (lunch/dinner) from info table."""
    result = {}
    for row in soup.select("div.rstinfo-table tr"):
        th = row.select_one("th")
        td = row.select_one("td")
        if not (th and td):
            continue
        label = th.get_text(strip=True)
        raw_value = td.get_text(strip=True)

        if "予算" in label and "集計" not in label:
            # Official budget: format is "昼の予算: ～￥999\n夜の予算: ～￥999" or "～￥999～￥999"
            # Look for span elements first
            spans = td.select("span")
            if len(spans) >= 2:
                result["budget_lunch"] = spans[0].get_text(strip=True)
                result["budget_dinner"] = spans[1].get_text(strip=True)
            else:
                # Raw text: split concatenated lunch+dinner budgets
                yen_positions = [m.start() for m in re.finditer(r'￥', raw_value)]
                # Check if there are two distinct budget values
                # "～￥999～￥999" has 2 ￥ but represents 2 values (～￥999 + ～￥999)
                # "￥10,000～￥14,999￥1,000～￥1,999" has 4 ￥ and represents 2 values
                budget_patterns = re.findall(r'(～?￥[\d,]+[～]￥[\d,]+)', raw_value)
                if len(budget_patterns) >= 2:
                    # Two full ranges: "￥10,000～￥14,999" + "￥1,000～￥1,999"
                    result["budget_lunch"] = budget_patterns[1]
                    result["budget_dinner"] = budget_patterns[0]
                elif len(budget_patterns) == 1 and len(yen_positions) >= 3:
                    # One full range + partial: treat as single value
                    result["budget"] = budget_patterns[0]
                elif len(yen_positions) == 2:
                    # Two ￥ symbols: distinguish single range vs two values
                    # "～￥999～￥999" -> starts with ～, two separate values
                    # "￥1,000～￥1,999" -> starts with ￥, single range
                    if raw_value.startswith('～'):
                        # Two values: "～￥X～￥Y"
                        m = re.match(r'(～￥[\d,]+)(～￥[\d,]+)', raw_value)
                        if m:
                            result["budget_lunch"] = m.group(1)
                            result["budget_dinner"] = m.group(2)
                        else:
                            result["budget"] = raw_value.split('利用')[0].strip()
                    else:
                        # Single range
                        second_end = len(raw_value)
                        for end_marker in ['利用金額', '利用', '詳細', '見る']:
                            idx = raw_value.find(end_marker)
                            if idx >= 0:
                                second_end = min(second_end, idx)
                        result["budget"] = raw_value[:second_end].strip()
                elif len(yen_positions) == 1:
                    result["budget"] = raw_value.split('利用')[0].strip()
                elif "￥" in raw_value:
                    result["budget"] = raw_value

        elif "予算" in label and "集計" in label:
            # Review-based budget: spans contain lunch and dinner
            spans = td.select("span")
            if len(spans) >= 2:
                result["budget_review_lunch"] = spans[0].get_text(strip=True)
                result["budget_review_dinner"] = spans[1].get_text(strip=True)

    return result


def extract_station_info(text: str) -> dict:
    """Parse station name and distance from access text."""
    result = {}
    # Pattern: 「上枝」駅から徒歩13分
    m = re.search(r"「([^」]+)」駅(?:から|まで)(?:徒歩)?(\d+)分", text)
    if m:
        result["station_name"] = m.group(1)
        result["walk_minutes"] = int(m.group(2))
    # Pattern: 上枝駅から1,012m (direct distance)
    m2 = re.search(r"([^駅]+?)駅から([\d,]+)m", text)
    if m2:
        station = m2.group(1).strip()
        # Skip if it looks like bus info
        if len(station) < 15 and not any(c in station for c in "⇔）☆バス停"):
            result["station_name"] = result.get("station_name", station)
            result["distance_from_station_m"] = int(m2.group(2).replace(",", ""))
    return result


def extract_info_table(soup: BeautifulSoup, restaurant_name: str = "") -> dict[str, Any]:
    """Extract all structured info from the detail table."""
    result = {}

    # Parse each row of the info table
    for row in soup.select("div.rstinfo-table tr"):
        th = row.select_one("th")
        td = row.select_one("td")
        if not (th and td):
            continue
        label = th.get_text(strip=True)
        value = td.get_text(strip=True)
        if not label or not value or len(label) > 50:
            continue

        if "ジャンル" in label:
            result["sub_genres"] = [g.strip() for g in value.split("、") if g.strip()]
        elif "お問い合わせ" in label:
            m = re.search(r"[\d\-]+", value)
            result["phone"] = m.group() if m else None
        elif "予約可否" in label:
            result["reservable"] = "可" in value and "不可" not in value
        elif "住所" in label:
            result["address"] = value.replace("大きな地図を見る", "").replace("周辺のお店を探す", "").strip()
        elif "交通手段" in label:
            station = extract_station_info(value)
            result.update(station)
            result["access_raw"] = value
        elif "営業時間" in label:
            result["hours_raw"] = value
        elif "予算" in label and "集計" not in label:
            # Official budget (already handled by extract_budget_info, but keep raw)
            pass
        elif "予算" in label and "集計" in label:
            spans = td.select("span")
            if len(spans) >= 2:
                result["budget_review_lunch"] = spans[0].get_text(strip=True)
                result["budget_review_dinner"] = spans[1].get_text(strip=True)
        elif "支払い方法" in label:
            result["payment"] = value
        elif "席数" in label:
            m = re.search(r"(\d+)席", value)
            result["seats"] = int(m.group(1)) if m else None
            result["seats_detail"] = value
        elif "個室" in label:
            result["private_room"] = "有" in value and "無" not in value
        elif "貸切" in label:
            result["rentable"] = "可" in value and "不可" not in value
        elif "禁煙" in label or "喫煙" in label:
            result["smoking"] = value
        elif "駐車場" in label:
            result["parking"] = "有" in value and "無" not in value
        elif "空間・設備" in label:
            result["features"] = [f.strip() for f in value.split("、") if f.strip()]
        elif "ドリンク" in label:
            result["drinks"] = [d.strip() for d in value.split("、") if d.strip()]
        elif "利用シーン" in label:
            result["scenes"] = value
        elif "ロケーション" in label:
            result["location_type"] = value
        elif "お子様" in label:
            result["child_friendly"] = "可" in value
            result["child_detail"] = value
        elif "お店のPR" in label:
            result["pr_text"] = value[:500] if len(value) > 500 else value

    # Budget extraction (needs nested span handling)
    budgets = extract_budget_info(soup)
    result.update(budgets)

    # Photo count: "写真2866" in the nav
    nav_items = soup.select(".rstdtl-navi__list-item-inner")
    for item in nav_items:
        text = item.get_text().replace("\n", "").replace("\r", "")
        # Look for "写真2866" pattern
        m = re.search(r"写真(\d+)", text)
        if m:
            result["photo_count"] = int(m.group(1))
            break

    # Status (closed/relocated)
    status_text = soup.select_one(".rdheader-status, .c-status")
    if status_text:
        text = status_text.get_text()
        if "閉店" in text:
            result["status"] = "closed"
        elif "移転" in text:
            result["status"] = "relocated"

    return result


# ─── Main Scraper ────────────────────────────────────────────────────────────

def scrape_restaurant(url: str, restaurant_name: str, session: requests.Session) -> dict[str, Any]:
    """Scrape a single Tabelog restaurant page."""
    for attempt in range(MAX_RETRIES):
        try:
            r = session.get(url, headers=HEADERS, timeout=TIMEOUT)
            if r.status_code == 404:
                return {"error": "not_found", "status": 404}
            elif r.status_code == 403:
                return {"error": "blocked", "status": 403}
            elif r.status_code != 200:
                return {"error": f"http_{r.status_code}", "status": r.status_code}

            soup = BeautifulSoup(r.text, "html.parser")

            # 1. Rating
            rating = None
            rating_el = soup.select_one(".rdheader-rating__score-val-dtl")
            if rating_el:
                m = re.search(r"(\d\.\d+)", rating_el.get_text())
                if m:
                    rating = float(m.group(1))
            # Fallback: og:description
            if not rating:
                og_desc = soup.find("meta", property="og:description")
                if og_desc:
                    m = re.search(r"(\d\.\d+)", og_desc.get("content", ""))
                    if m:
                        rating = float(m.group(1))

            # 2. Review & saved counts
            review_count, saved_count = extract_review_saved_counts(soup)

            # 3. Rating distribution
            rating_distribution = extract_score_boxes(soup)

            # 4. Awards
            awards = extract_awards(soup)

            # 5. Info table
            info = extract_info_table(soup, restaurant_name)

            return {
                "rating": rating,
                "review_count": review_count,
                "saved_count": saved_count,
                "rating_distribution": rating_distribution,
                "awards": awards,
                **info,
            }

        except requests.exceptions.Timeout:
            log_error(f"Timeout attempt {attempt+1} for {url}")
            time.sleep(RETRY_DELAY * (attempt + 1))
        except requests.exceptions.RequestException as e:
            log_error(f"Request error attempt {attempt+1} for {url}: {e}")
            time.sleep(RETRY_DELAY * (attempt + 1))
        except Exception as e:
            log_error(f"Parse error for {url}: {e}")
            return {"error": f"parse_error: {e}"}

    return {"error": "max_retries_exceeded"}


def save_checkpoint(progress: dict):
    """Save progress to checkpoint file."""
    with open(CHECKPOINT_FILE, "w", encoding="utf-8") as f:
        json.dump(progress, f, ensure_ascii=False, indent=2)


def load_checkpoint() -> dict:
    """Load checkpoint if exists."""
    if CHECKPOINT_FILE.exists():
        with open(CHECKPOINT_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"processed": [], "enriched_data": [], "errors": []}


CLEAN_FIELDS = [
    "id", "name", "area", "genre", "region", "tabelog_url", "image_url",
    "holiday", "is_new",
    # Scraped fields
    "rating", "review_count", "saved_count", "rating_distribution", "awards",
    "budget_lunch", "budget_dinner", "budget",
    "budget_review_lunch", "budget_review_dinner",
    "phone", "reservable", "address", "station_name",
    "walk_minutes", "distance_from_station_m", "access_raw",
    "hours_raw", "seats", "seats_detail", "private_room",
    "rentable", "smoking", "parking", "features", "drinks",
    "scenes", "location_type", "child_friendly", "child_detail",
    "pr_text", "sub_genres", "photo_count", "status", "payment",
    # Meta
    "scrape_error", "scrape_success", "scraped_at",
]


def main():
    parser = argparse.ArgumentParser(description="Tabelog Hyakumeiten Scraper")
    parser.add_argument("--delay", type=float, default=3.0, help="Delay between requests (seconds)")
    parser.add_argument("--batch", type=int, default=0, help="Process only first N restaurants (0=all)")
    parser.add_argument("--resume", action="store_true", help="Resume from checkpoint")
    parser.add_argument("--test", action="store_true", help="Test mode: process only 5 restaurants")
    args = parser.parse_args()

    # Load input data
    if not INPUT_FILE.exists():
        log.error(f"Input file not found: {INPUT_FILE}")
        sys.exit(1)

    with open(INPUT_FILE, "r", encoding="utf-8") as f:
        restaurants = json.load(f)

    log.info(f"Loaded {len(restaurants)} restaurants from {INPUT_FILE}")

    # Apply filters
    if args.test:
        restaurants = restaurants[:5]
        log.info("TEST MODE: processing 5 restaurants")
    elif args.batch > 0:
        restaurants = restaurants[:args.batch]
        log.info(f"BATCH MODE: processing first {args.batch} restaurants")

    # Load checkpoint if resuming
    if args.resume:
        checkpoint = load_checkpoint()
        processed_ids = set(checkpoint.get("processed", []))
        # Enriched data may or may not have "id" field — handle both cases
        raw_enriched = checkpoint.get("enriched_data", [])
        if raw_enriched and "id" in raw_enriched[0]:
            enriched = {r["id"]: r for r in raw_enriched}
        else:
            # No id field: pair with processed_ids by position
            enriched = {}
            for idx, rid in enumerate(processed_ids):
                if idx < len(raw_enriched):
                    enriched[rid] = raw_enriched[idx]
        errors = checkpoint.get("errors", [])
        log.info(f"Resuming from checkpoint: {len(processed_ids)} already processed")
    else:
        processed_ids = set()
        enriched = {}
        errors = []

    # Build output with base data
    output_data = {}
    for r in restaurants:
        output_data[r["id"]] = dict(r)
        if r["id"] in enriched:
            output_data[r["id"]].update(enriched[r["id"]])

    # Session with connection pooling
    session = requests.Session()
    session.headers.update(HEADERS)

    total = len(restaurants)
    start_time = time.time()
    processed_count = len(processed_ids)
    error_count = len(errors)

    log.info(f"Starting scrape: {total} restaurants, {processed_count} already done")
    log.info(f"Delay: {args.delay}s, Max retries: {MAX_RETRIES}")

    for i, restaurant in enumerate(restaurants):
        rid = restaurant["id"]
        url = restaurant["tabelog_url"]

        if rid in processed_ids:
            continue

        # Progress logging
        elapsed = time.time() - start_time
        remaining = total - processed_count - 1
        eta = (elapsed / max(processed_count, 1)) * remaining if processed_count > 0 else 0
        log.info(f"[{processed_count}/{total}] ETA:{eta/60:.0f}m | {restaurant['name']} ({rid})")

        # Scrape
        page_start = time.time()
        data = scrape_restaurant(url, restaurant["name"], session)

        if "error" in data:
            error_count += 1
            error_msg = f"{rid} | {restaurant['name']} | {url} | {data['error']}"
            log.warning(f"ERROR: {error_msg}")
            log_error(error_msg)
            errors.append({"id": rid, "name": restaurant["name"], "url": url, "error": data["error"]})
            output_data[rid]["scrape_error"] = data["error"]
        else:
            output_data[rid].update(data)
            output_data[rid]["scraped_at"] = datetime.now().isoformat()
            output_data[rid]["scrape_success"] = True
            enriched[rid] = {k: v for k, v in data.items()}

        processed_ids.add(rid)
        processed_count += 1

        # Periodic checkpoint save (every 50 restaurants)
        if processed_count % 10 == 0:
            # Build enriched data with IDs for reliable resume
            enriched_list = []
            for r in output_data.values():
                if r.get("scrape_success"):
                    enriched_list.append(r)
            save_checkpoint({
                "processed": list(processed_ids),
                "enriched_data": enriched_list,
                "errors": errors,
                "last_processed_at": datetime.now().isoformat(),
            })
            # Intermediate enriched output
            with open(OUTPUT_FILE.with_suffix(".partial.json"), "w", encoding="utf-8") as f:
                json.dump(list(output_data.values()), f, ensure_ascii=False, indent=2)
            log.info(f"Checkpoint saved: {processed_count}/{total}")

        # Rate limiting — human-like: at least MIN_DELAY per page total
        MIN_DELAY = 10.0  # minimum seconds per page (request + wait)
        if i < total - 1:
            request_time = time.time() - page_start  # time since scrape started
            remaining = max(0, MIN_DELAY - request_time)
            if remaining > 0:
                log.info(f"  ⏳ Request took {request_time:.1f}s, waiting {remaining:.1f}s more (min {MIN_DELAY}s/page)")
                time.sleep(remaining)

    # ─── Final Saves ─────────────────────────────────────────────────────

    # Full enriched output
    final_data = list(output_data.values())
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(final_data, f, ensure_ascii=False, indent=2)

    # Clean output (only relevant fields)
    clean_output = []
    for r in final_data:
        clean_r = {k: v for k, v in r.items() if k in CLEAN_FIELDS}
        clean_output.append(clean_r)
    with open(BASE_DIR / "hyakumeiten-restaurants-clean.json", "w", encoding="utf-8") as f:
        json.dump(clean_output, f, ensure_ascii=False, indent=2)

    elapsed = time.time() - start_time
    success_count = processed_count - error_count

    log.info(f"\n{'='*60}")
    log.info(f"SCRAPING COMPLETE")
    log.info(f"Total: {total} | Success: {success_count} | Errors: {error_count}")
    log.info(f"Time: {elapsed/60:.1f} minutes")
    log.info(f"Output: {OUTPUT_FILE}")
    log.info(f"Clean output: {BASE_DIR / 'hyakumeiten-restaurants-clean.json'}")

    # Final checkpoint
    enriched_list_final = []
    for r in final_data:
        if r.get("scrape_success"):
            enriched_list_final.append(r)
    save_checkpoint({
        "processed": list(processed_ids),
        "enriched_data": enriched_list_final,
        "errors": errors,
        "completed_at": datetime.now().isoformat(),
        "total": total,
        "success": success_count,
        "errors_count": error_count,
        "elapsed_minutes": elapsed / 60,
    })


if __name__ == "__main__":
    main()
